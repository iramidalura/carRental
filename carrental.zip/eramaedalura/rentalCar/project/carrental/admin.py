from django.contrib import admin
from carrental.models import Car, Rental

# Register your models here.
admin.site.register(Car)
admin.site.register(Rental)
