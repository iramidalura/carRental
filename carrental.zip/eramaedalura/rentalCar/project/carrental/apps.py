from django.apps import AppConfig


class CarrentalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'carrental'
